# Import commands for terminal:
# pip install opencv-python
# pip install matplotlib

# Import the necessary libraries
import cv2  # OpenCV for image processing
import numpy as np  # NumPy for numerical operations
import matplotlib.pyplot as plt  # Matplotlib for plotting

# Function to apply thresholding on a grayscale image
def apply_threshold(image):
    """
    This function applies binary thresholding to a grayscale image.
    Args:
    - image: Input image in grayscale
    Returns:
    None
    """
    try:
        # Apply binary thresholding
        # The threshold value is set to 127, and the maximum value is 255
        _, thresholded_image = cv2.threshold(image, 127, 255, cv2.THRESH_BINARY)

        # Display original and thresholded images
        plt.figure(figsize=(10, 5))

        plt.subplot(1, 2, 1)
        plt.title('Original Grayscale Image')
        plt.imshow(image, cmap='gray')
        plt.axis('off')

        plt.subplot(1, 2, 2)
        plt.title('Thresholded Image')
        plt.imshow(thresholded_image, cmap='gray')
        plt.axis('off')

        plt.show()

    except Exception as e:
        print(f"An error occurred during thresholding: {e}")

# Main code to load the image and apply thresholding
if __name__ == "__main__":
    try:
        # Load the image (make sure you have an image named 'sample_image.jpg' in the same folder as this script)
        image = cv2.imread('sample_image.jpg')

        # Convert to grayscale
        if image is None:
            raise FileNotFoundError("Error: Image not found. Make sure the image file exists in the same directory.")
        
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Apply thresholding
        apply_threshold(gray_image)

    except FileNotFoundError as fnf_error:
        print(fnf_error)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")
