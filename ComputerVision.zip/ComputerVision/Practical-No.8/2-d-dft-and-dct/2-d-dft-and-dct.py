# Import commands for terminal:
# pip install opencv-python
# pip install numpy
# pip install matplotlib

# Import the necessary libraries
import cv2  # OpenCV for image processing
import numpy as np  # NumPy for numerical operations
import matplotlib.pyplot as plt  # Matplotlib for plotting

def compute_dft(image):
    """
    Compute the 2-D Discrete Fourier Transform (DFT) of the input image.
    
    Args:
    - image: Input grayscale image
    
    Returns:
    - dft: DFT of the image
    - dft_shifted: Shifted DFT for visualization
    """
    try:
        # Compute the 2D DFT
        dft = np.fft.fft2(image)
        dft_shifted = np.fft.fftshift(dft)  # Shift zero frequency components to center
        
        # Calculate the magnitude spectrum
        magnitude_spectrum = np.log(np.abs(dft_shifted) + 1)  # Log scale for better visibility
        
        return dft, magnitude_spectrum

    except Exception as e:
        print(f"An error occurred while computing DFT: {e}")

def compute_dct(image):
    """
    Compute the 2-D Discrete Cosine Transform (DCT) of the input image.
    
    Args:
    - image: Input grayscale image
    
    Returns:
    - dct: DCT of the image
    """
    try:
        # Compute the 2D DCT
        dct = cv2.dct(np.float32(image))  # DCT requires float32 input
        return dct

    except Exception as e:
        print(f"An error occurred while computing DCT: {e}")

# Main code to load the image and apply DFT and DCT
if __name__ == "__main__":
    try:
        # Load the image (ensure there is an image named 'sample_image.jpg' in the same folder)
        image = cv2.imread('sample_image.jpg')

        # Check if the image was loaded successfully
        if image is None:
            raise FileNotFoundError("Error: Image not found. Make sure the image file exists in the same directory.")

        # Convert to grayscale
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Compute DFT
        dft, magnitude_spectrum = compute_dft(gray_image)

        # Compute DCT
        dct = compute_dct(gray_image)

        # Display original image, DFT magnitude spectrum, and DCT
        plt.figure(figsize=(15, 5))

        plt.subplot(1, 3, 1)
        plt.title('Original Image')
        plt.imshow(gray_image, cmap='gray')
        plt.axis('off')

        plt.subplot(1, 3, 2)
        plt.title('DFT Magnitude Spectrum')
        plt.imshow(magnitude_spectrum, cmap='gray')
        plt.axis('off')

        plt.subplot(1, 3, 3)
        plt.title('DCT of Image')
        plt.imshow(dct, cmap='gray')
        plt.axis('off')

        plt.show()

    except FileNotFoundError as fnf_error:
        print(fnf_error)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")
