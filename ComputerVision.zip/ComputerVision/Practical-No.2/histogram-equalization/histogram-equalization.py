# Import commands for terminal:
# pip install opencv-python
# pip install matplotlib

# Import the necessary libraries
import cv2  # OpenCV for image processing
import numpy as np  # NumPy for array manipulation
import matplotlib.pyplot as plt  # Matplotlib for plotting

# Function to perform histogram equalization on an image
def histogram_equalization(image):
    """
    This function performs histogram equalization on the input image and displays the result.
    Args:
    - image: Input image in BGR format
    Returns:
    None
    """
    try:
        # Convert the image to grayscale
        grayscale_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Perform histogram equalization
        equalized_image = cv2.equalizeHist(grayscale_image)

        # Display the original and equalized images
        plt.figure(figsize=(12, 6))
        
        # Show original image
        plt.subplot(1, 2, 1)
        plt.title('Original Grayscale Image')
        plt.imshow(grayscale_image, cmap='gray')
        plt.axis('off')

        # Show equalized image
        plt.subplot(1, 2, 2)
        plt.title('Equalized Image')
        plt.imshow(equalized_image, cmap='gray')
        plt.axis('off')

        plt.show()

    except Exception as e:
        print(f"An error occurred while processing the image: {e}")

# Main code to load the image and perform histogram equalization
if __name__ == "__main__":
    try:
        # Load the image (make sure you have an image named 'sample_image.jpg' in the same folder as this script)
        image = cv2.imread('sample_image.jpg')

        # Check if the image was loaded properly
        if image is None:
            raise FileNotFoundError("Error: Image not found. Make sure the image file exists in the same directory.")

        # Perform histogram equalization
        histogram_equalization(image)

    except FileNotFoundError as fnf_error:
        print(fnf_error)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")
